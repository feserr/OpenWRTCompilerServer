#include <stdio.h>

int main(int argc, const char *argv[]) {
    prif("Hello world!");

    return 0;
}

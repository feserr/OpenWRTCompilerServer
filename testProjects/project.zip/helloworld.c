#include <stdio.h>

int main(int argc, const char *argv[]) {
    printf("Hello world!");

    return 0;
}
